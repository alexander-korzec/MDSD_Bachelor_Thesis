import "./App.css";
import ExtendedJsonFroms from './ExtendedJsonForms';
import { LocationType } from './load/LocationType';
import { UIScreen, FormBind, TableBind, UIBind } from './data/UIFile';
import { BindFile, loadBindFile } from './data/BindFile';
import uiFile2 from './models/uifiles/uimodel.json'
import bindFile2 from './models/bindFile.json'
import Form from './components/Form';
import Table from './components/Table';
import { BindSubject, DataSubject } from './components/Observer';
import { useState, Fragment } from "react";

const options = {
    type: LocationType.local
}

const App = () => {
    //return ExtendedJsonFroms('models/links.json', options);
    //return ExtendedJsonFroms('models/uimodel.json', 'models/links.json', options);
    const [uiFile, setUiFile] = useState<UIScreen>(uiFile2);
    const [bindFile, setBindFile] = useState<BindFile>(loadBindFile(bindFile2));
    const [dataSubject, setDataSubject] = useState<DataSubject>(new DataSubject());
    return (
        <Fragment>
            {
                uiFile.components.map((bind : UIBind) => {
                    if(bind.type === "form") {
                        return Form(bindFile, bind as FormBind, dataSubject);
                    } else if(bind.type === "table") {
                        return Table(bindFile, bind as TableBind, dataSubject);
                    }
                    return <Fragment></Fragment>
                })
            }
        </Fragment>
    );
}

export default App;

