import { Fragment, useState, useEffect, useRef, useCallback } from "react";
import {
    materialCells,
    materialRenderers,
} from "@jsonforms/material-renderers";
import { JsonForms } from "@jsonforms/react";
import { makeStyles } from "@mui/styles";
import Button from '@mui/material/Button';
import SendIcon from '@mui/icons-material/Send';
import BuildIcon from '@mui/icons-material/Build';

import { BindFile, BindLocation, FormBindLocation } from "../data/BindFile";
import { FormBind, FormBindIdentifier } from "../data/UIFile";
import { fetchElement, addData } from "../data/Fetch";
import { Observer, BindSubject } from "./Observer";

const useStyles = makeStyles({
    container: {
        padding: "1em",
        width: "100%",
    },
    title: {
        textAlign: "center",
        padding: "0.25em",
    },
    dataContent: {
        display: "flex",
        justifyContent: "center",
        borderRadius: "0.25em",
        backgroundColor: "#cecece",
        marginBottom: "1rem",
    },
    resetButton: {
        margin: "auto !important",
        display: "block !important",
    },
    demoform: {
        margin: "auto",
        padding: "1rem",
    },
});

const renderers = [
    ...materialRenderers
];

const filterEditSearchCriteria = (uiIDs : FormBindIdentifier, formState : any) : [string, string][] => {
    const searchCriteria : string[] = uiIDs.edit_search_criteria
    const result : any[] = []
    searchCriteria.forEach(key => {
        if(key in formState) {
            result.push([ "id", formState[key] ]);
        }
    })
    return result;
};

const flattenJSON = (obj : object = {}, res : object = {}) => {
    Object.keys(obj).forEach(key =>  {
        if(typeof obj[key as keyof typeof obj] !== 'object') {
            res[key as keyof typeof obj] = obj[key as keyof typeof obj];
        } else {
            flattenJSON(obj[key as keyof typeof obj], res);
        }
    });
    return res;
 };

 export interface TableColumn {
    Header: string,
    accessor: string
}

const Form = (bindFile: BindFile, formBind : FormBind, bindSubject : BindSubject) : JSX.Element => {
    const classes = useStyles();
    const [formState, setFormState] = useState<any>({});
    const [uischema, setUISchema] = useState<any>(null);
    const [uiBindings, setUIBindings] = useState<FormBindLocation>();
    const [isSending, setIsSending] = useState(false);
    const isMounted = useRef(true);
    const uiIDs : FormBindIdentifier = formBind.binding_ids;
    const bindings : Map<string, BindLocation> = bindFile.bindings;
    const editItemSetFormData = useCallback(async () => {
        if (isSending) {
            return;
        }
        setIsSending(true);
        const flattenFormState = flattenJSON(formState);
        const reqParams : [string, string][] = filterEditSearchCriteria(uiIDs, flattenFormState);
        await fetchElement(bindFile, uiBindings?.edit_id)((formState : Array<any>) => {
            if(formState.length > 0) {
                setFormState(formState[0]);
            }
        }, reqParams);
        if(isMounted.current) {
            setIsSending(false);
        }
        //bindSubject.notify(uiBindings?.edit_id); Not needed
    }, [isSending]);
    useEffect(() => {
        return () => {
            isMounted.current = false
        }
    }, []);
    useEffect(() => {
        setUIBindings(bindings.get(uiIDs.id) as FormBindLocation);
    }, [uiIDs.id]);
    useEffect(() => {
        fetchElement(bindFile, uiBindings?.form_id)(setUISchema);
    }, [uiBindings]);
    return (
        !(uischema && uiBindings) ? (
            <Fragment>Loading...</Fragment>
        ) : (
            <Fragment>
                <div className={classes.demoform}>
                    <JsonForms
                        schema={uischema}
                        data={formState}
                        renderers={renderers}
                        cells={materialCells}
                        onChange={({ errors, data }) => setFormState(data)}
                    />
                </div>
                <Button
                    variant="contained"
                    endIcon={<BuildIcon />}
                    onClick={editItemSetFormData}
                    disabled={isSending}
                    fullWidth
                >
                    Edit
                </Button>
                <Button
                    variant="contained"
                    endIcon={<SendIcon />}
                    onClick={() => { 
                        addData(bindFile, uiBindings.submit_id)(formState);
                        let formState2 = formState;
                        delete formState2.id;
                        bindSubject.notify(uiBindings.submit_id);
                        setFormState(formState2);
                    }}
                    fullWidth
                >
                    Submit
                </Button>
            </Fragment>
        )
    );
}

export default Form;