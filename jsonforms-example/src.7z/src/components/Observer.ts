import { BindLocation, RemotePath } from '../data/BindFile';

export interface Observer {
    // Receive update from subject.
    update(key : string): void;
}

export interface Subject {
    // Attach an observer to the subject.
    attach(observer : Observer): void;
    // Detach an observer from the subject.
    detach(observer : Observer): void;
    // Notify all observers about an event.
    notify(key : string): void;
}

export interface BindSubject {
    attach(observer : Observer, bindLocation : BindLocation): void;
    detach(observer : Observer, bindLocation : BindLocation): void;
    notify(remotePath : RemotePath | undefined): void;

}

class SingleBindSubject implements Subject {

    private observers: Observer[] = [];

    public attach(observer: Observer): void {
        const isExist = this.observers.includes(observer);
        if (!isExist) {
            this.observers.push(observer);
        }
    }

    public detach(observer: Observer): void {
        const observerIndex = this.observers.indexOf(observer);
        if (observerIndex !== -1) {
            this.observers.splice(observerIndex, 1);
        }
    }

    public notify(key : string): void {
        for (const observer of this.observers) {
            observer.update(key);
        }
    }
}

export class DataSubject implements BindSubject {

    private subjects : Map<string, Subject>;

    constructor() {
        this.subjects = new Map<string, Subject>();
    }

    public attach(observer : Observer, bindLocation : BindLocation): void {
        console.log(observer, bindLocation)
        Object.keys(bindLocation).forEach(key => {
            const remotePath : RemotePath = bindLocation[key as keyof typeof bindLocation];
            const binding_id : string = remotePath.location_path;
            let subject : Subject | undefined = this.subjects.get(binding_id);
            if(!subject) {
                const newSubject : Subject = new SingleBindSubject();
                this.subjects.set(binding_id, newSubject);
                subject = newSubject;
            }
            subject.attach(observer);
        });
        console.log(this)
    }

    public detach(observer : Observer, bindLocation : BindLocation): void {
        Object.keys(bindLocation).forEach(key => {
            const remotePath : RemotePath = bindLocation[key as keyof typeof bindLocation];
            const binding_id : string = remotePath.location_path;
            let subject : Subject | undefined = this.subjects.get(binding_id);
            if(subject) {
                subject.detach(observer);
            }
        });
    }

    public notify(remotePath : RemotePath | undefined): void {
        if(remotePath) {
            const path : string = remotePath.location_path
            let subject : Subject | undefined = this.subjects.get(path);
            if(subject) {
                subject.notify(path);
            }
        }
    }

}
