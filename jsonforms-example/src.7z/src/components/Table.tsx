// @ts-nocheck

import { Fragment, useState, useEffect } from "react";
import { useTable } from 'react-table';
import styled from 'styled-components';

import { BindFile, BindLocation, TableBindLocation } from "../data/BindFile";
import { TableBind, TableBindIdentifier } from "../data/UIFile";
import { fetchElement } from "../data/Fetch";

import { Observer, BindSubject } from "./Observer";

const Styles = styled.div`
  padding: 1rem;
  table {
    border-spacing: 0;
    border: 1px solid black;
    tr {
      :last-child {
        td {
          border-bottom: 0;
        }
      }
    }
    th,
    td {
      margin: 0;
      padding: 0.5rem;
      border-bottom: 1px solid black;
      border-right: 1px solid black;
      :last-child {
        border-right: 0;
      }
    }
  }
`;

function ReactTable({ columns, data }) {
    const {
      getTableProps,
      getTableBodyProps,
      headerGroups,
      rows,
      prepareRow,
    } = useTable({
      columns,
      data,
    })
    return (
      <table {...getTableProps()}>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(column => (
                <th {...column.getHeaderProps()}>{column.render('Header')}</th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {rows.map((row, i) => {
            prepareRow(row)
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => {
                  return <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                })}
              </tr>
            )
          })}
        </tbody>
      </table>
    )
}

class TableDataObserver implements Observer {
    public needsFetchUpdate : boolean = false;
    private updateFunc : FunctionConstructor

    constructor(updateFunc : Function) {
        this.updateFunc = updateFunc;
    }

    public update(key : string) : void {
        this.updateFunc(true);
    }
}

const flattenJSON = (obj : object = {}, res : object = {}) => {
    Object.keys(obj).forEach(key =>  {
        if(typeof obj[key as keyof typeof obj] !== 'object') {
            res[key as keyof typeof obj] = obj[key as keyof typeof obj];
        } else {
            flattenJSON(obj[key as keyof typeof obj], res);
        }
    });
    return res;
 };

const getAttributes = (obj : object | undefined) : TableColumn[] => {
    if(!obj) {
        return [];
    }
    const result : TableColumn[] = [];
    getAttributesHelper(obj, result);
    return result;
};

const getAttributesHelper = (obj : object, result : TableColumn[], identifier : string = "") : void => {
    if(!("properties" in obj)) {
        const atomarAttr : TableColumn = {
            Header: "",
            accessor: identifier
        }
        if("title" in obj) {
            atomarAttr.Header = obj["title" as keyof typeof obj];
        }
        result.push(atomarAttr);
    } else {
        const propertiesObj : object = obj["properties" as keyof typeof obj];
        Object.keys(propertiesObj).forEach((key : string) => {
            if(key !== "type") {
                getAttributesHelper(propertiesObj[key as keyof typeof propertiesObj], result, key);
            }
        });
    }
};

const Table = (bindFile: BindFile, tableBind : TableBind, bindSubject : BindSubject) : JSX.Element => {
    const bindings : Map<string, BindLocation> = bindFile.bindings;
    const tableIDs : TableBindIdentifier = tableBind.binding_ids;
    const [tableDataState, setTableDataState] = useState<any>([]);
    const [tableHeaderState, setTableHeaderState] = useState<any>([]);
    const [uiBindings, setUIBindings] = useState<TableBindLocation>();
    const [needsUpdate, setNeedsUpdate] = useState<boolean>(false);
    const [tableDataObserver, setTableDataObserver] = useState<Observer>(new TableDataObserver(setNeedsUpdate));
    console.log("Needs Update:", needsUpdate)
    useEffect(() => {
        bindSubject.attach(tableDataObserver, bindFile.bindings.get(tableIDs.id));
        setTableDataObserver(tableDataObserver);
        setUIBindings(bindings.get(tableIDs.id) as TableBindLocation);
    }, []);
    useEffect(() => {
        fetchElement(bindFile, uiBindings?.fetch_id)((data) => {
            setTableDataState(data.map(row => flattenJSON(row)))
            setNeedsUpdate(false);
        });
    }, [bindFile, uiBindings, needsUpdate]);
    useEffect(() => {
        fetchElement(bindFile, uiBindings?.format_id)(setTableHeaderState);
    }, [bindFile, uiBindings]);
    return (
        <Fragment>
            <Styles>
                <ReactTable
                    columns={tableHeaderState}
                    data={tableDataState}
                />
            </Styles>
        </Fragment>
    );
}

export default Table;