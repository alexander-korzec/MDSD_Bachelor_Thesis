// @ts-nocheck

import { Fragment, useState, useEffect } from "react";
import { JsonForms } from "@jsonforms/react";
import { makeStyles } from "@mui/styles";
import $RefParser from "@apidevtools/json-schema-ref-parser";
import "./App.css";
import {
    materialCells,
    materialRenderers,
} from "@jsonforms/material-renderers";
import Button from '@mui/material/Button';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { Loader } from './load/Loader';
import { LocationFile, processLocationFile } from './load/ConstructLinksObj';
import { LocationType } from './load/LocationType';
import axios from 'axios';

const useStyles = makeStyles({
    container: {
        padding: "1em",
        width: "100%",
    },
    title: {
        textAlign: "center",
        padding: "0.25em",
    },
    dataContent: {
        display: "flex",
        justifyContent: "center",
        borderRadius: "0.25em",
        backgroundColor: "#cecece",
        marginBottom: "1rem",
    },
    resetButton: {
        margin: "auto !important",
        display: "block !important",
    },
    demoform: {
        margin: "auto",
        padding: "1rem",
    },
});

const renderers = [
    ...materialRenderers
];

const convertToPrettyName = (schema: any, key: string) => {
    let properties = schema.properties
    if("title" in properties[key]) {
      return properties[key].title;
    }
    return key;
  };
  
  const extractNames = (schema: any) => (Object.keys(schema.properties));
  
  const showData = (schema: any, rows: any[]) => {
    const header = extractNames(schema);
    return (
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 650 }}>
          <TableHead>
            <TableRow>
              { header.map((x: string, idx: number) => <TableCell key={x + '-head-' + idx}>{convertToPrettyName(schema, x)}</TableCell>) }
            </TableRow>
          </TableHead>
          <TableBody>
          {
            rows.map((row: any, idx: number) => (
              <TableRow
                key={row.name + '-body-' + idx}
                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
              >
                { 
                  header.map((key: string, idx2: number) => (
                    <TableCell key={row.name + '-body-' + idx + '-' + idx2}>
                      { typeof row[key] === "boolean" ? (row[key] ? "YES" : "") : row[key] }
                    </TableCell>
                  ))
                }
              </TableRow>
            ))
          }
          </TableBody>
        </Table>
      </TableContainer>
    );
  }
  

const useFetch = (location: string | undefined, fileloader: Loader | undefined) => {
    const [data, setData] = useState<any>(null);
    const [error, setError] = useState<any>(null);
    useEffect(() => {
        (async () => {
            try {
                if(fileloader && location) {
                    const { success : boolean, data, error } = await fileloader.loadFile(location);
                    setData(data);
                }
            } catch(err) {
                setError(err);
            }
        })();
    }, [location]);
    return { data, error };
};

const buildRemotePath = (apiLocation : any, links : Map<string, string>, id : string) : any => {
    const protocol = apiLocation.protocol;
    const path = apiLocation.root;
    const port = apiLocation.port;
    return `${protocol}://${path}:${port}/${links.get(id)}`
}

const id = (x : any) : any => (x);

const Form = (formPath : string, options : any, formState : any, setFormState : Function) => {
    const classes = useStyles();
    const uiModelLoader : Loader = new Loader(async (data : any) => (await $RefParser.dereference(data)), options);
    const uimodel = useFetch(formPath, uiModelLoader);
    return !uimodel.data ? (
        <Fragment>Loading...</Fragment>
    ) : (
        <div className={classes.demoform}>
            <JsonForms
                schema={uimodel.data}
                data={formState}
                renderers={renderers}
                cells={materialCells}
                onChange={({ errors, data }) => setFormState(data)}
            />
        </div>
    )
}

// Wichtig: Erstmal Send für EINE Form!!!
const ExtendedJsonForms = (linksFilePath : string, options : any) => {
    const classes = useStyles();
    const [formData, setFormData] = useState<any>({});
    const linksFileLoader : Loader = new Loader(id, options);
    let uimodel = undefined;
    //const uiModelLoader : Loader = new Loader(async (data : any) => (await $RefParser.dereference(data)), { type: options.uimodel.type })
    const linksFile = useFetch(linksFilePath, linksFileLoader);
    //const uimodel = useFetch(uimodelPath, uiModelLoader);
    let linksCollection : any | undefined = undefined;
    /* ROOT SCHEMA LADEN */
    let rootSchemaPath = undefined;
    let rootSchemaLoader = undefined;
    if(linksFile && linksFile.data) {
        linksCollection = processLocationFile(linksFile.data as LocationFile);
        rootSchemaPath = buildRemotePath(linksCollection.apis[0].attributes, linksCollection.bindRecv, "root");
        rootSchemaLoader = new Loader(id, { type: LocationType.remote });
    }
    const rootSchema = useFetch(rootSchemaPath, rootSchemaLoader);
    /* ROOT SCHEMA BEARBEITEN -> ERSTE SEITE LADEN */
    let staffSchemaPath = undefined;
    let staffSchemaLoader = undefined;
    if(linksCollection && rootSchema && rootSchema.data) {
        staffSchemaPath = buildRemotePath(linksCollection.apis[0].attributes, linksCollection.bindRecv, rootSchema.data.attributes.pages[0]);
        staffSchemaLoader = new Loader(id, { type: LocationType.remote });
    }
    /* ERSTE SEITE BEARBEITEN -> HIER EINE FORM * BUTTON (SOLLTE IM RETURN STEHEN?) */
    const staffSchema = useFetch(staffSchemaPath, staffSchemaLoader);
    let staffFormPath = undefined;
    let staffFormPathSend = undefined
    let staffFormLoader = undefined;
    if(linksCollection && staffSchema && staffSchema.data) {
        staffFormPath = buildRemotePath(linksCollection.apis[0].attributes, linksCollection.bindRecv, staffSchema.data.attributes.layout[0].id);
        staffFormPathSend = buildRemotePath(linksCollection.apis[0].attributes, linksCollection.bindSend, staffSchema.data.attributes.layout[0].id);
        staffFormLoader = new Loader(id, { type: LocationType.remote });
    }
    uimodel = useFetch(staffFormPath, staffFormLoader);
    return !uimodel || !uimodel.data ? (
        <Fragment>Loading...</Fragment>
    ) : (
        <div className={classes.demoform}>
            <JsonForms
                schema={uimodel.data}
                data={formData}
                renderers={renderers}
                cells={materialCells}
                onChange={({ errors, data }) => setFormData(data)}
            />
            <Button
                onClick={() => {
                    axios.post(staffFormPathSend, formData)
                }}
            >
                Send
            </Button>
        </div>
    )
    /*return !uimodel ? (
        <Fragment>Loading...</Fragment>
    ) : (
        <Fragment>
            <div className={classes.demoform}>
                <JsonForms
                    schema={uimodel}
                    data={formData}
                    renderers={renderers}
                    cells={materialCells}
                    onChange={({ errors, data }) => setFormData(data)}
                />
            </div>
        </Fragment>
    );*/
    /*
    <Fragment>
            {
                staffSchema.data.attributes.layout.map(x => {
                    const path = buildRemotePath(linksCollection.apis[0].attributes, linksCollection.bindRecv, x.id);
                    return Form(path, { type: LocationType.remote }, formData, setFormData)
               })
            }
    </Fragment>
    */
};

export default ExtendedJsonForms;