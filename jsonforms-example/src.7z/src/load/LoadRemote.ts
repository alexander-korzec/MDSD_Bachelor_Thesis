import { LoadStrategy } from './LoadStrategy';
import { LoaderOptions } from './LoaderOptions';
import axios from 'axios';

export class LoadRemote implements LoadStrategy {
    public async loadFile(location : string, callback : Function, loaderOptions : LoaderOptions): Promise<any> {
        let success = true;
        let data, error;
        try {
            const res = await axios.get(location);
            data = await callback(res.data);
        } catch(err) {
            console.log(err);
            success = false;
            error = err;
        }
        return { success, data, error };
    }
}