import { LoaderOptions } from './LoaderOptions';
import { LoadStrategy } from './LoadStrategy';
import { LoadLocal } from './LoadLocal';
import { LoadRemote } from './LoadRemote';
import { LocationType } from './LocationType';

const id = (x : any) : any => (x);

export class Loader {
    private callback : Function
    private options : LoaderOptions
    private loadStrategy : LoadStrategy

    constructor(callback : Function = id , options : LoaderOptions = { type: LocationType.local, encoding: 'utf-8' }) {
        this.callback = callback;
        this.options = options;
        this.loadStrategy = (options.type === LocationType.local) ? new LoadLocal() : new LoadRemote();
    }

    public async loadFile(location : string) : Promise<any> {
        return await this.loadStrategy.loadFile(location, this.callback, this.options);
    }
}