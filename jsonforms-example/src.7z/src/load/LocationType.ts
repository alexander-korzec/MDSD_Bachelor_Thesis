export enum LocationType {
    local = "local",
    remote = "remote"
}