import { LoadStrategy } from './LoadStrategy';
import { LoaderOptions } from './LoaderOptions';

export class LoadLocal implements LoadStrategy {
    public async loadFile(location : string, callback : Function, loaderOptions : LoaderOptions): Promise<any> {
        const file = require(`./../${location}`);
        const data = await callback(file);
        return { success: true, data, error: {} };
    }
}