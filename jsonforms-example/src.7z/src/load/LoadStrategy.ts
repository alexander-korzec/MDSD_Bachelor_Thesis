import { LoaderOptions } from "./LoaderOptions";

export interface LoadStrategy {
    loadFile(location : string, callback : Function, loaderOptions : LoaderOptions): Promise<any>;
}