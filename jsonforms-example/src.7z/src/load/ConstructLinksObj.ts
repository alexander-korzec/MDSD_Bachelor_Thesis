export interface LocalLocation {
    root: string
}

export interface RemoteLocation {
    root: string,
    port: string,
    protocol?: string,
}

export interface Bind {
    element: string,
    path: string,
    type: string
}

export interface APILocation {
    type: string,
    attributes: LocalLocation | RemoteLocation
}

export interface Location {
    type: string,
    attributes: LocalLocation | RemoteLocation | Bind
}

export interface LocationFile {
    data: Location[]
}

export interface LocationCollection {
    apis: APILocation[],
    bindRecv: Map<string, string>,
    bindSend: Map<string, string>
}

export const processLocationFile = (links : LocationFile) : LocationCollection => {
    const result : LocationCollection = {
        apis: [],
        bindRecv: new Map<string, string>(),
        bindSend: new Map<string, string>()
    }
    links.data.forEach(location => {
        if(location.type === "local" || location.type === "remote") {
            result.apis.push(location as APILocation);
        } else if(location.type === "bind") {
            const x = location.attributes as unknown as Bind;
            if(x.type === "recv") {
                result.bindRecv.set(x.element, x.path);
            } else if(x.type === "send") {
                result.bindSend.set(x.element, x.path);
            }
        }
    });
    return result;
}