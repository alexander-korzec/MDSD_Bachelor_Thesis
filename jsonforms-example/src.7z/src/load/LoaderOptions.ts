import { LocationType } from './LocationType';

export interface LoaderOptions {
    type: LocationType,
    encoding?: string
}