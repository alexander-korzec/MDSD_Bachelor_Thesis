import axios from 'axios';
import { BindFile, RemotePath, RemoteLocation } from "./BindFile";

const createPath = (remoteLocation : RemoteLocation, path : string) : string => {
    const protocol : string = (remoteLocation.protocol) ? remoteLocation.protocol : "http";
    const base : string = remoteLocation.address;
    const port : number = remoteLocation.port;
    return `${protocol}://${base}:${port}/${path}`;
}

const addParams = (url : String, params : [string, string][]) : string => {
    return [url].concat([params.map(x => (`${x[0]}=${x[1]}`)).join('&')]).join('?');
};

const setUIState = (apiPath : string) : Function => {
    return (
        async (setData : Function, searchParams : [string, string][] = []) => {
            try {
                let path = apiPath;
                if(searchParams.length > 0) {
                    path = addParams(path, searchParams);
                }
                const res = await axios.get(path);
                setData(res.data);
            } catch(err) {
                console.error(err);
            }
        }
    );
};

const addDataToAPI = (apiPath : string) : Function => (
    async (data : any) => {
        try {
            if("id" in data) {
                await axios.delete(`${apiPath}/${data.id}`);
            }
            await axios.post(apiPath, data);
        } catch(err) {
            console.error(err);
        }
    }
);

const genericReq = (bindFile : BindFile, remotePath : RemotePath | undefined, callback : Function) : Function => {
    const apis = bindFile.apis;
    if(remotePath) {
        const remoteLocation : RemoteLocation | undefined = apis.get(remotePath.location_id);
        if(remoteLocation) {
            const apiPath = createPath(remoteLocation, remotePath.location_path);
            return callback(apiPath)
        }
    }
    return (setData : Function) => {};
};

export const fetchElement = (bindFile : BindFile, remotePath : RemotePath | undefined) : Function  => (
    genericReq(bindFile, remotePath, setUIState)
);

export const addData = (bindFile : BindFile, remotePath : RemotePath | undefined) : Function => (
    genericReq(bindFile, remotePath, addDataToAPI)
);