export interface UIBind {
    type: string
}

export interface TableBind extends UIBind {
    binding_ids: TableBindIdentifier
}

export interface FormBind extends UIBind {
    binding_ids: FormBindIdentifier
}

export interface FormBindIdentifier {
    id: string,
    edit_search_criteria: string[]
}

export interface TableBindIdentifier {
    id: string
}

export interface UIScreen {
    id: string,
    components: UIBind[]
}