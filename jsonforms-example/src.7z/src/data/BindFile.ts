export interface RemoteLocation {
    protocol?: string,
    port: number,
    address: string
}

export interface RemotePath {
    location_id: string,
    location_path: string
}

export interface BindLocation {}

export interface SimpleBindLocation extends BindLocation {
    id: RemotePath
}

export interface FormBindLocation extends BindLocation {
    form_id: RemotePath,
    submit_id: RemotePath,
    edit_id: RemotePath
}

export interface TableBindLocation extends BindLocation {
    fetch_id: RemotePath,
    format_id?: RemotePath
}

export interface BindFile {
    apis: Map<string, RemoteLocation>,
    firstBind: RemotePath,
    bindings: Map<string, BindLocation>
}

export const loadBindFile = (bindFileJSON : any) : BindFile => {
    const bindFile : BindFile = {
        apis: new Map<string, RemoteLocation>(Object.entries(bindFileJSON.apis)),
        firstBind: bindFileJSON.firstBind,
        bindings: new Map<string, BindLocation>(Object.entries(bindFileJSON.bindings))
    };
    return bindFile;
}